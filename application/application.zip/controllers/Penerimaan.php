<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penerimaan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('penerimaan_model', 'satuan_model', 'barang_model', 'cabang_model'));
        if (empty($this->session->userdata('username'))) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['penerimaanjkt'] = $this->penerimaan_model->getDataByIdCabang('21001');
        $data['penerimaantsk'] = $this->penerimaan_model->getDataByIdCabang('21002');
        $this->load->view('vPenerimaan', $data);
    }

    public function detail($idData)
    {
        $data['penerimaan'] = $this->penerimaan_model->getDataById($idData);
        $this->load->view('vPenerimaanDetail', $data);
    }

    public function print($idData)
    {
        $data['penerimaan'] = $this->penerimaan_model->getDataById($idData);
        $this->load->view('vPenerimaanPrint', $data);
    }
    public function print2($idData)
    {
        $data['penerimaan'] = $this->penerimaan_model->getDataById($idData);
        $this->load->view('vPenerimaanPrint2', $data);
    }

    public function add($idCabang)
    {
        $data['idbarangmasuk']   = $this->penerimaan_model->getIdData(date('y'));
        $data['barang'] = $this->barang_model->getDataByIdCabang($idCabang);
        $data['satuan'] = $this->satuan_model->getAlldata();
        $data['cabang'] = $this->cabang_model->getAlldata();
        $this->load->view('vPenerimaanAdd', $data);
    }

    function saveData()
    {
        $penerimaan            = $this->input->post('penerimaan');
        $penerimaanDetail      = $this->input->post('penerimaanDetail');
        $stock                 = 0;

        //insert Data
        $this->penerimaan_model->saveData($penerimaan, 'tblbarangmasuk');

        for ($i = 0; $i < count($penerimaanDetail); $i++) {
            //insert Data Detail
            $this->penerimaan_model->saveData($penerimaanDetail[$i], 'tblbarangmasukdetail');

            //Update Penambahan Stock
            $stockAwal = $this->barang_model->getDataById($penerimaanDetail[$i]['idbarang']);
            $stock = $stockAwal[0]['stock'] + $penerimaanDetail[$i]['qtymasuk'];
            $arrStock = array(
                'stock' => $stock,
                'hargaterakhir' => $penerimaanDetail[$i]['hargasatuan']
            );
            // print_r($stockAwal);
            $this->barang_model->updateData($penerimaanDetail[$i]['idbarang'], $arrStock, 'tblmbarang');
        }
    }

    function delete($idData)
    {
        if (isset($idData)) {
            //getpenerimaandetail
            $penerimaanDetail = $this->penerimaan_model->getDetailDataById($idData);
            // print_r($penerimaanDetail);
            for ($i = 0; $i < count($penerimaanDetail); $i++) {
                //update pengurangan stock
                $stockAwal = $this->barang_model->getStockById($penerimaanDetail[$i]['idbarang']);
                $stock = $stockAwal[0]['stock'] - $penerimaanDetail[$i]['qtymasuk'];
                $arrStock = array(
                    'stock' => $stock
                );
                $this->barang_model->updateData($penerimaanDetail[$i]['idbarang'], $arrStock, 'tblmbarang');
            }
            //delete data
            $this->penerimaan_model->deleteData($idData, "tblbarangmasuk");
        }
        return "Data Berhasil Di Delete";
    }










    // function edit($idData)
    // {
    //     if (isset($idData)) {
    //         $data['barang']     = $this->barang_model->getDataById($idData);
    //         $data['lokasi'] = $this->lokasi_model->getAlldata();
    //         $data['kategori'] = $this->kategori_model->getAlldata();
    //         $data['satuan'] = $this->satuan_model->getAlldata();
    //     }
    //     $this->load->view('master/vBarangEdit', $data);
    // }

    // public function updateData($idData)
    // {
    //     $barang = $this->input->post('barang');
    //     $this->barang_model->updateData($idData, $barang, 'tblmbarang');
    //     print_r($this->input->post());
    // }
}
