<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Inventaris extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('inventaris_model', 'kategori_model', 'cabang_model'));
        if (empty($this->session->userdata('username'))) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['inventarisjkt'] = $this->inventaris_model->getDataByIdCabang('21001');
        $data['inventaristsk'] = $this->inventaris_model->getDataByIdCabang('21002');
        $this->load->view('master/vInventaris', $data);
    }

    public function add()
    {
        $data['idinventaris']   = $this->inventaris_model->getIDData(date('y'));
        $data['kategori'] = $this->kategori_model->getAllData();
        $data['cabang'] = $this->cabang_model->getAlldata();
        $this->load->view('master/vInventarisAdd', $data);
    }

    public function print($idCabang)
    {
        $data['inventaris'] = $this->inventaris_model->getRekap($idCabang);
        // print_r($data);
        $this->load->view('master/vInventarisPrint', $data);
    }

    public function saveData()
    {
        $inventaris = $this->input->post('inventaris');
        $this->inventaris_model->saveData($inventaris, 'tblminventaris');
        print_r($this->input->post());
    }

    function edit($idData)
    {
        if (isset($idData)) {
            $data['kategori'] = $this->kategori_model->getAllData();
            $data['inventaris']     = $this->inventaris_model->getinventarisById($idData);
            $data['cabang'] = $this->cabang_model->getAlldata();
        }
        $this->load->view('master/vInventarisEdit', $data);
    }

    function updateData($idData)
    {
        $inventaris = $this->input->post('inventaris');
        $this->inventaris_model->updateData($idData, $inventaris, 'tblminventaris');
        print_r($this->input->post());
    }

    function delete($idData)
    {
        if (isset($idData)) {
            $this->inventaris_model->deleteData($idData, "tblminventaris");
        }
        return "Data Berhasil Di Delete";
    }

    function getInventarisDetail($idcabang)
    {
        $kategori    = $this->input->post('kategori');
        $data['inventaris'] = $this->inventaris_model->getInventarisByKategori($kategori, $idcabang);
        echo json_encode($data);
        // echo $idsiswa;  
    }
}
