create tblmcabang idcabang varchar(5), cabang varchar(50)
Alter tblmbarang add idcabang varchar(5)
UPDATE tblmbarang SET idcabang='21001'

ALTER TABLE tblminventaris CHANGE lokasi idcabang VARCHAR(5);

UPDATE tblminventaris SET idcabang='21001' WHERE idcabang='JAKBA'
UPDATE tblminventaris SET idcabang='21002' WHERE idcabang='TASIK'

UPDATE tblminventaris SET kondisi='Rusak' WHERE kondisi='RUSAK'
UPDATE tblminventaris SET kondisi='Lama' WHERE kondisi='LAMA'
UPDATE tblminventaris SET kondisi='Baik' WHERE kondisi='BAIK'
UPDATE tblminventaris SET kondisi='Baru' WHERE kondisi='BARU'
UPDATE tblmprofile SET appname='Akses Gemilang' WHERE id='1'

ALTER TABLE tblbarangmasuk ADD COLUMN IF NOT EXISTS idcabang VARCHAR(5)
UPDATE tblbarangmasuk SET idcabang='21001'

ALTER TABLE tblbarangkeluar ADD COLUMN IF NOT EXISTS idcabang VARCHAR(5)
UPDATE tblbarangkeluar SET idcabang='21001'