<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('pengeluaran_model', 'penerimaan_model', 'kategori_model', 'satuan_model', 'barang_model'));
        if (empty($this->session->userdata('username'))) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['barang'] = $this->barang_model->getAlldata();
        $data['penerimaan'] = $this->penerimaan_model->getAlldata();
        $data['pengeluaran'] = $this->pengeluaran_model->getAlldata();
        $this->load->view('dashboard', $data);
        // print_r($data);

    }
}
