<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('kategori_model',  'satuan_model'));
        if (empty($this->session->userdata('username'))) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['kategori'] = $this->kategori_model->getAlldata();
        // print_r($this->session->userdata());
        $this->load->view('master/vKategori', $data);
    }

    public function add()
    {
        $data['idkategori']   = $this->kategori_model->getIdData(date('y'));
        $this->load->view('master/vKategoriAdd', $data);
    }

    public function saveData()
    {
        $data = $this->input->post('kategori');
        $this->kategori_model->saveData($data, 'tblmkategori');
        print_r($this->input->post());
    }

    function edit($idData)
    {
        if (isset($idData)) {
            $data['kategori']     = $this->kategori_model->getDataById($idData);
        }
        $this->load->view('master/vKategoriEdit', $data);
    }

    public function updateData($idData)
    {
        $kategori = $this->input->post('kategori');
        $this->kategori_model->updateData($idData, $kategori, 'tblmkategori');
        print_r($this->input->post());
    }

    function delete($idData)
    {
        if (isset($idData)) {
            $this->kategori_model->deleteData($idData, "tblmkategori");
        }
        return "Data Berhasil Di Delete";
    }

}
