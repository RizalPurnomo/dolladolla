<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengeluaran extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('pengeluaran_model', 'satuan_model', 'barang_model', 'cabang_model'));
        if (empty($this->session->userdata('username'))) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['pengeluaranjkt'] = $this->pengeluaran_model->getDataByIdCabang('21001');
        $data['pengeluarantsk'] = $this->pengeluaran_model->getDataByIdCabang('21002');
        $this->load->view('vPengeluaran', $data);
    }

    public function detail($idData)
    {
        $data['pengeluaran'] = $this->pengeluaran_model->getDataById($idData);
        $this->load->view('vPengeluaranDetail', $data);
    }

    public function print($idData)
    {
        $data['pengeluaran'] = $this->pengeluaran_model->getDataById($idData);
        $this->load->view('vPengeluaranPrint', $data);
    }

    public function print2($idData)
    {
        $data['pengeluaran'] = $this->pengeluaran_model->getDataById($idData);
        $this->load->view('vPengeluaranPrint2', $data);
    }

    public function add($idCabang)
    {
        $data['idbarangmasuk']   = $this->pengeluaran_model->getIdData(date('y'));
        $data['barang'] = $this->barang_model->getDataByIdCabang($idCabang);
        $data['satuan'] = $this->satuan_model->getAlldata();
        $data['cabang'] = $this->cabang_model->getAlldata();
        $this->load->view('vPengeluaranAdd', $data);
    }

    function saveData()
    {
        $pengeluaran            = $this->input->post('pengeluaran');
        $pengeluaranDetail      = $this->input->post('pengeluaranDetail');
        $stock                 = 0;

        //insert Data
        $this->pengeluaran_model->saveData($pengeluaran, 'tblbarangkeluar');

        for ($i = 0; $i < count($pengeluaranDetail); $i++) {
            //insert Data Detail
            $this->pengeluaran_model->saveData($pengeluaranDetail[$i], 'tblbarangkeluardetail');

            //Update Penambahan Stock
            $stockAwal = $this->barang_model->getStockById($pengeluaranDetail[$i]['idbarang']);
            $stock = $stockAwal[0]['stock'] - $pengeluaranDetail[$i]['qtykeluar'];
            $arrStock = array(
                'stock' => $stock
            );
            $this->barang_model->updateData($pengeluaranDetail[$i]['idbarang'], $arrStock, 'tblmbarang');
        }
    }

    function delete($idData)
    {
        if (isset($idData)) {
            //getpengeluarandetail
            $pengeluaranDetail = $this->pengeluaran_model->getDetailDataById($idData);
            // print_r($pengeluaranDetail);
            for ($i = 0; $i < count($pengeluaranDetail); $i++) {
                //update pengurangan stock
                $stockAwal = $this->barang_model->getStockById($pengeluaranDetail[$i]['idbarang']);
                $stock = $stockAwal[0]['stock'] + $pengeluaranDetail[$i]['qtykeluar'];
                $arrStock = array(
                    'stock' => $stock
                );
                $this->barang_model->updateData($pengeluaranDetail[$i]['idbarang'], $arrStock, 'tblmbarang');
            }
            //delete data
            $this->pengeluaran_model->deleteData($idData, "tblbarangkeluar");
        }
        return "Data Berhasil Di Delete";
    }










    // function edit($idData)
    // {
    //     if (isset($idData)) {
    //         $data['barang']     = $this->barang_model->getDataById($idData);
    //         $data['lokasi'] = $this->lokasi_model->getAlldata();
    //         $data['kategori'] = $this->kategori_model->getAlldata();
    //         $data['satuan'] = $this->satuan_model->getAlldata();
    //     }
    //     $this->load->view('master/vBarangEdit', $data);
    // }

    // public function updateData($idData)
    // {
    //     $barang = $this->input->post('barang');
    //     $this->barang_model->updateData($idData, $barang, 'tblmbarang');
    //     print_r($this->input->post());
    // }
}
