<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<script type="text/javascript">
    function getDateTime($tgl) {
        if ($tgl == "now") {
            var now = new Date();
        } else {
            var now = $tgl;
        }
        var year = now.getFullYear();
        var month = now.getMonth() + 1;
        var day = now.getDate();
        var hour = now.getHours();
        var minute = now.getMinutes();
        var second = now.getSeconds();
        if (month.toString().length == 1) {
            var month = '0' + month;
        }
        if (day.toString().length == 1) {
            var day = '0' + day;
        }
        if (hour.toString().length == 1) {
            var hour = '0' + hour;
        }
        if (minute.toString().length == 1) {
            var minute = '0' + minute;
        }
        if (second.toString().length == 1) {
            var second = '0' + second;
        }
        var dateTime = year + '/' + month + '/' + day + ' ' + hour + ':' + minute + ':' + second;
        return dateTime;
    }

    function addBarang() {
        strBarang = $("#barang").val();
        qty = $("#qty").val()
        harga = $("#harga").val();
        arrBarang = strBarang.split(' || ');


        if (strBarang == "" || qty == "") {
            Swal.fire({
                icon: 'warning',
                text: 'Harap lengkapi data',
            })
            return;
        }
        if (parseInt(arrBarang[2]) < parseInt(qty)) {
            Swal.fire({
                icon: 'warning',
                text: 'Stock di gudang tidak cukup',
            })
            return;
        }

        var row = $("#dataBarang tbody tr");
        for (var i = 0; i < row.length; i++) {
            var col = $(row[i]).find("td");
            if (col[1].innerHTML == arrBarang[0]) {
                Swal.fire({
                    icon: 'warning',
                    text: 'Tidak dapat memasukkan Id Barang yang sama',
                })
                return;
            }
        }
        $("#dataBarang tbody").append(
            `<tr>
                <td>- </td>
                <td>${arrBarang[0]}</td>
                <td>${arrBarang[1]}</td>
                <td>${arrBarang[2]}</td>
                <td>${qty}</td>
                <td>${arrBarang[4]}</td>
                <td>${harga}</td>
            </tr>`
        );

    }

    function savePengeluaran() {
        let today = new Date(),
            curr_hour = today.getHours(),
            curr_min = today.getMinutes(),
            curr_sec = today.getSeconds();

        tanggal = getDateTime(new Date($("#datepicker").val() + " " + curr_hour + ":" + curr_min + ":" + curr_sec));

        if ($("#idUser").val() == "") {
            Swal.fire({
                icon: 'warning',
                text: 'Session habis, Harap logout dan login kembali',
            })
            return;
        }
        if ($("#idpengeluaran").val() == "" || $("#datepicker").val() == "" || $("#idtiket").val() == "" || $("#area").val() == "") {
            Swal.fire({
                icon: 'warning',
                text: 'Harap Melengkapi Data!',
            })
            return;
        }

        var row = $("#dataBarang tbody tr");
        var jml = 0;
        var dataDetail = new Array();
        for (var i = 0; i < row.length; i++) {
            var col = $(row[i]).find("td");
            dataDetail.push({
                "idbarangkeluar": $("#idpengeluaran").val(),
                "idbarang": col[1].innerHTML,
                "qtykeluar": col[4].innerHTML,
                "hargasatuan": col[6].innerHTML,
            });
        }

        let dataArray = {
            "pengeluaran": {
                "idbarangkeluar": $("#idpengeluaran").val(),
                "idtiket": $("#idtiket").val(),
                "iduser": $("#idUser").val(),
                "tanggal": tanggal,
                "tiketarea": $("#area").val(),
                "pengambilan": $("#lokasipengambilan").val(),
                "ketkeluar": $("#keterangan").val(),
                "idcabang": $("#cabang").val()
            },
            "pengeluaranDetail": dataDetail
        }

        console.log(dataArray);
        // return;
        $.ajax({
            type: "POST",
            data: dataArray,
            url: '<?php echo base_url('pengeluaran/saveData'); ?>',
            success: function(result) {
                Swal.fire({
                    icon: 'success',
                    title: 'Data Berhasil Disimpan',
                    showConfirmButton: false,
                    timer: 1500
                })

                console.log(result);
                window.location = "<?php echo base_url(); ?>pengeluaran/detail/" + $("#idpengeluaran").val();
            }
        })

    }
</script>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Tambah Pengeluaran Barang</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url($this->uri->segment(1)); ?>"><?php echo $this->uri->segment(1); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(2); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Tambah Pengeluaran Barang</h4>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="form-group row">
                                <input type="text" class="form-control" id="idUser" value="<?php echo $this->session->userdata('iduser'); ?>" hidden disabled placeholder="ID User">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Id Pengeluaran</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="idpengeluaran" value="<?php echo $idbarangmasuk; ?>" disabled placeholder="ID Barang Masuk">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Cabang</label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" style="width: 100%;" id="cabang" disabled>
                                        <option value="">-- Pilih Cabang --</option>
                                        <?php for ($a = 0; $a < count($cabang); $a++) {  ?>
                                            <option value="<?php echo $cabang[$a]['idcabang'] ?>" <?php if ($cabang[$a]['idcabang'] == $this->uri->segment(3)) {
                                                                                                        echo 'selected';
                                                                                                    } ?>>
                                                <?php echo $cabang[$a]['cabang'];  ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Tiket / SC</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="idtiket" placeholder="Tiket / SC">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Tanggal</label>
                                <div class="col-sm-10">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control pull-right" id="datepicker">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Tiket Area</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="area" placeholder="Tiket Area">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Lokasi Pengambilan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="lokasipengambilan" placeholder="Lokasi Pengambilan">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Keterangan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="keterangan" placeholder="Keterangan">
                                </div>
                            </div>

                            <hr />
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Pilih Barang</label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" style="width: 100%;" id="barang">
                                        <option value="">-- Pilih Barang --</option>
                                        <?php for ($a = 0; $a < count($barang); $a++) {  ?>
                                            <?php
                                            $strBarang = $barang[$a]['idbarang'] . " || " . $barang[$a]['kodebarang'] . " || " . $barang[$a]['namabarang']  . " || " . $barang[$a]['stock'] . " || " . $barang[$a]['satuan'];
                                            ?>
                                            <option value="<?php echo $strBarang ?>">
                                                <?php echo $strBarang;  ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label"></label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" id="qty" placeholder="Qty">
                                </div>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" id="harga" placeholder="Harga penjualan">
                                </div>
                                <button class="col-sm-1 btn btn-block btn-primary" onclick="addBarang()">+</button>
                            </div>
                            <table id="dataBarang" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Id Barang</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Qty</th>
                                        <th>Satuan</th>
                                        <th>Harga Beli</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                            <br />
                            <!-- <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Pilih Barang</label>
                                <div class="col-sm-8">
                                    <select class="form-control select2" style="width: 100%;" id="barang">
                                        <option value="">-- Pilih Barang --</option>
                                        <?php for ($a = 0; $a < count($barang); $a++) {  ?>
                                            <?php
                                            $strBarang = $barang[$a]['idbarang'] . " || " . $barang[$a]['kodebarang'] . " || " . $barang[$a]['namabarang']  . " || " . $barang[$a]['stock'];
                                            ?>
                                            <option value="<?php echo $strBarang ?>">
                                                <?php echo $strBarang;  ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-sm-1">
                                    <input type="text" class="form-control" id="qty" placeholder="Qty">
                                </div>
                                <button class="col-sm-1 btn btn-block btn-primary" onclick="addBarang()">+</button>
                            </div>
                            <table id="dataBarang" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Id Barang</th>
                                        <th>Kode Barang</th>
                                        <th>Nama Barang</th>
                                        <th>Qty</th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table> -->
                            <br />
                            <div class="card-footer">
                                <button onclick="savePengeluaran()" class="btn btn-info">Simpan</button>
                                <!-- <button class="btn btn-default float-right">Cancel</button> -->
                            </div>
                        </div>
                        <!-- ./card-body -->

                    </div>
                    <!-- /.card -->
                </div>



            </div>
            <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php $this->load->view('footer'); ?>