<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<script type="text/javascript">
    function deleteData(id) {
        let idData = $("#" + id + " td")[1].innerHTML;
        Swal.fire({
            title: 'Apakah yakin data akan di hapus?',
            showCancelButton: true,
            confirmButtonText: `Delete`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>penerimaan/delete/" + idData,
                    success: function(html) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Data Berhasil Dihapus',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        console.log(html);
                        var url = "<?php echo base_url(); ?>penerimaan/";
                        window.location.href = url;
                    }
                })
            } else {
                return;
            }
        })
    }
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Penerimaan Barang</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>dashboard">home</a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo base_url(); ?>penerimaan/add/21001" class="btn btn-app">
                                <i class="fas fa-user"></i> JAKARTA
                            </a>
                            <br />
                            PENERIMAAN BARANG JAKARTA
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Penerimaan</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <!-- <th>PIC</th> -->
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $totals = 0;
                                        if (!empty($penerimaanjkt)) {
                                            for ($a = 0; $a < count($penerimaanjkt); $a++) { ?>
                                                <?php
                                                $idpenerimaanjkt = $penerimaanjkt[$a]['idbarangmasuk'];
                                                $total = $penerimaanjkt[$a]['qtymasuk'] * $penerimaanjkt[$a]['hargasatuan'];
                                                $totals = $totals + $total;
                                                ?>
                                                <tr id="penerimaanjkt<?php echo $idpenerimaanjkt; ?>">
                                                    <td><?php echo $a + 1 ?></td>
                                                    <td><?php echo $idpenerimaanjkt ?></td>
                                                    <td><?php echo $penerimaanjkt[$a]['tanggal'] ?></td>
                                                    <td><?php echo $penerimaanjkt[$a]['ketmasuk'] ?></td>
                                                    <td><?php echo $penerimaanjkt[$a]['kodebarang'] ?></td>
                                                    <td><?php echo $penerimaanjkt[$a]['namabarang'] ?></td>
                                                    <td align="right"><?php echo number_format($penerimaanjkt[$a]['qtymasuk']) ?></td>
                                                    <td align="right"><?php echo number_format($penerimaanjkt[$a]['hargasatuan']) ?></td>
                                                    <td align="right"><?php echo number_format($total); ?></td>
                                                    <!-- <td><?php echo $penerimaanjkt[$a]['realname'] ?></td> -->
                                                    <td>
                                                        <a class="btn btn-large btn-success " href="<?php echo base_url('penerimaan/detail/') . $penerimaanjkt[$a]['idbarangmasuk']; ?>">Detail</a>
                                                        | <a class="btn btn-large btn-danger" href="javascript:deleteData('penerimaanjkt<?php echo $penerimaanjkt[$a]['idbarangmasuk']; ?>')">Delete</a>
                                                    </td>
                                                </tr>
                                        <?php }
                                        } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><b><?php echo number_format($totals); ?></b></td>
                                            <!-- <td></td> -->
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Penerimaan</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <!-- <th>PIC</th> -->
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo base_url(); ?>penerimaan/add/21002" class="btn btn-app">
                                <i class="fas fa-user"></i> TASIK
                            </a>
                            <br />
                            PENERIMAAN BARANG TASIK
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Penerimaan</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <th>PIC</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $totals = 0;
                                        if (!empty($penerimaantsk)) {
                                            for ($a = 0; $a < count($penerimaantsk); $a++) { ?>
                                                <?php
                                                $idpenerimaantsk = $penerimaantsk[$a]['idbarangmasuk'];
                                                $total = $penerimaantsk[$a]['qtymasuk'] * $penerimaantsk[$a]['hargasatuan'];
                                                $totals = $totals + $total;
                                                ?>
                                                <tr id="penerimaantsk<?php echo $idpenerimaantsk; ?>">
                                                    <td><?php echo $a + 1 ?></td>
                                                    <td><?php echo $idpenerimaantsk ?></td>
                                                    <td><?php echo $penerimaantsk[$a]['tanggal'] ?></td>
                                                    <td><?php echo $penerimaantsk[$a]['ketmasuk'] ?></td>
                                                    <td><?php echo $penerimaantsk[$a]['kodebarang'] ?></td>
                                                    <td><?php echo $penerimaantsk[$a]['namabarang'] ?></td>
                                                    <td align="right"><?php echo number_format($penerimaantsk[$a]['qtymasuk']) ?></td>
                                                    <td align="right"><?php echo number_format($penerimaantsk[$a]['hargasatuan']) ?></td>
                                                    <td align="right"><?php echo number_format($total); ?></td>
                                                    <td><?php echo $penerimaantsk[$a]['realname'] ?></td>
                                                    <td>
                                                        <a class="btn btn-large btn-success " href="<?php echo base_url('penerimaan/detail/') . $penerimaantsk[$a]['idbarangmasuk']; ?>">Detail</a>
                                                        | <a class="btn btn-large btn-danger" href="javascript:deleteData('penerimaantsk<?php echo $penerimaantsk[$a]['idbarangmasuk']; ?>')">Delete</a>
                                                    </td>
                                                </tr>
                                        <?php }
                                        } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><b><?php echo number_format($totals); ?></b></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Penerimaan</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <th>PIC</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>

        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>