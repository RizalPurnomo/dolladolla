<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Pengeluaran Barang Detail</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url($this->uri->segment(1)); ?>"><?php echo $this->uri->segment(1); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(2); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Pengeluaran Barang Detail</h5>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="invoice p-3 mb-3">
                                <!-- title row -->
                                <div class="row">
                                    <div class="col-12">
                                        <h4>
                                            <!-- <i class="fas fa-globe"></i> PT. TELAGA PELANGI -->
                                            <img src="<?php echo base_url(); ?>assets/images/logo.jpg" width="100"> <br />
                                            <b>PT. TELAGA PELANGI </b>
                                            <small class="float-right"><b>ID #<?php echo $pengeluaran[0]['idbarangkeluar']; ?></b></small><br />
                                            <small class="float-right"><b>Tiket #<?php echo $pengeluaran[0]['idtiket']; ?></b></small><br />
                                            <small class="float-right">Tanggal: <?php echo $pengeluaran[0]['tanggal']; ?></small>
                                        </h4>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- info row -->
                                <div class="row invoice-info">
                                    <div class="col-sm-4 invoice-col">
                                        <strong>Area</strong>
                                        <address>
                                            <?php echo $pengeluaran[0]['tiketarea']; ?><br>

                                        </address>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-sm-4 invoice-col">
                                        <strong>Lokasi Pengambilan</strong>
                                        <address>
                                            <?php echo $pengeluaran[0]['pengambilan']; ?><br>
                                        </address>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-sm-4 invoice-col">
                                        <strong>Keterangan</strong>
                                        <address>
                                            <?php echo $pengeluaran[0]['ketkeluar']; ?><br>
                                        </address>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->

                                <!-- Table row -->
                                <div class="row">
                                    <div class="col-12 table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Kode Barang</th>
                                                    <th>Nama Barang</th>
                                                    <th>qty</th>
                                                    <th>Satuan</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (!empty($pengeluaran)) {
                                                    for ($a = 0; $a < count($pengeluaran); $a++) { ?>
                                                        <tr>
                                                            <td><?php echo $a + 1 ?></td>
                                                            <td><?php echo $pengeluaran[$a]['kodebarang'] ?></td>
                                                            <td><?php echo $pengeluaran[$a]['namabarang'] ?></td>
                                                            <td><?php echo $pengeluaran[$a]['qtykeluar'] ?></td>
                                                            <td><?php echo $pengeluaran[$a]['satuan'] ?></td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->


                                <!-- this row will not appear when printing -->
                                <div class="row no-print">
                                    <div class="col-12">
                                        <a href="<?php echo base_url('pengeluaran/print/') . $pengeluaran[0]['idbarangkeluar']; ?>" target="_blank" class="btn btn-primary"><i class="fas fa-print"></i> Print</a>
                                        <a href="<?php echo base_url('pengeluaran/print2/') . $pengeluaran[0]['idbarangkeluar']; ?>" target="_blank" class="btn btn-primary"><i class="fas fa-print"></i> Print2</a>
                                    </div>
                                </div>
                            </div>
                            <!-- /.invoice -->


                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>



        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>