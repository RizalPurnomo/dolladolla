<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<script type="text/javascript">
    function getStock() {
        let idbarang = $("#barang").val();
        $.ajax({
            type: "GET",
            url: "<?php echo base_url(); ?>report/getStock/" + idbarang,
            success: function(result) {
                let myObj = JSON.parse(result)
                let objPenerimaan = myObj['penerimaan'];
                let objPengeluaran = myObj['pengeluaran'];
                // return;
                let txt = "";
                let totals = 0;
                let qtymasuks = 0;
                let qtykeluars = 0;
                let totalPengeluaran = 0;

                txt += `            
                        <div class="col-md-6">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Pemasukan</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Qty Masuk</th>
                                                <th>Harga Beli</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>`
                for (x in objPenerimaan) {
                    total = parseInt(objPenerimaan[x].qtymasuk) * parseInt(objPenerimaan[x].hargasatuan);
                    qtymasuks = qtymasuks + parseInt(objPenerimaan[x].qtymasuk);
                    totals = totals + total;
                    txt += `
                                            <tr>
                                                <td>${parseInt(x) + parseInt(1)}</td>
                                                <td>${objPenerimaan[x].tanggal}</td>
                                                <td>${objPenerimaan[x].qtymasuk}</td>
                                                <td>${objPenerimaan[x].hargasatuan}</td>
                                                <td>${total}</td>
                                            </tr>
                                        `;
                }
                txt += `
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th></th>
                                                <th></th>
                                                <th>${qtymasuks}</th>
                                                <th></th>
                                                <th>${totals}</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h3 class="card-title">Pengeluaran</h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Qty Keluar</th>
                                                <th>Harga Jual</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>`
                for (x in objPengeluaran) {
                    total = parseInt(objPengeluaran[x].qtykeluar) * parseInt(objPengeluaran[x].hargasatuan);
                    qtykeluars = qtykeluars + parseInt(objPengeluaran[x].qtykeluar);
                    totalPengeluaran = totalPengeluaran + total;
                    txt += `
                                            <tr>
                                                <td>${parseInt(x) + parseInt(1)}</td>
                                                <td>${objPengeluaran[x].tanggal}</td>
                                                <td>${objPengeluaran[x].qtykeluar}</td>
                                                <td>${objPengeluaran[x].hargasatuan}</td>
                                                <td>${total}</td>
                                            </tr>
                                        `;
                }
                txt += `
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th></th>
                                                <th></th>
                                                <th>${qtykeluars}</th>
                                                <th></th>
                                                <th>${totalPengeluaran}</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    `
                document.getElementById("divStock").innerHTML = txt;


            }
        })
    }
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Report Stock</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>dashboard">home</a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Barang</label>
                                <div class="col-sm-10">
                                    <select class="form-control select2" style="width: 100%;" id="barang">
                                        <option value="">-- Pilih Barang--</option>
                                        <?php for ($a = 0; $a < count($barang); $a++) {  ?>
                                            <?php
                                            $strBarang = $barang[$a]['idbarang'] . " || " . $barang[$a]['kodebarang'] . " || " . $barang[$a]['namabarang']  . " || " . $barang[$a]['stock'] . " || " . $barang[$a]['satuan'];
                                            ?>
                                            <option value="<?php echo $barang[$a]['idbarang'] ?>">
                                                <?php echo $strBarang  ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <!-- <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Tanggal Cut Off</label>
                                <div class="col-sm-10">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                        <input type="text" class="form-control pull-right" id="datepicker">
                                    </div>
                                </div>
                            </div> -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label"></label>
                                <div class="col-sm-10">
                                    <button onclick="getStock()" class="btn btn-info">Proses</button>
                                </div>
                            </div>
                            <div class="row" id="divStock">
                                <div class="col-md-6">
                                    <div class="card card-primary">
                                        <div class="card-header">
                                            <h3 class="card-title">Pemasukan</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="box-body table-responsive">
                                                <table class="table table-bordered table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th>Tanggal</th>
                                                            <th>Qty Masuk</th>
                                                            <th>Harga Beli</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="card card-primary">
                                        <div class="card-header">
                                            <h3 class="card-title">Pengeluaran</h3>
                                        </div>
                                        <div class="card-body">
                                            dfdf
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>



        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>