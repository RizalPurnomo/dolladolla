<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<script type="text/javascript">
    function deleteData(id) {
        let idData = $("#" + id + " td")[1].innerHTML;
        Swal.fire({
            title: 'Apakah yakin data akan di hapus?',
            showCancelButton: true,
            confirmButtonText: `Delete`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>pengeluaran/delete/" + idData,
                    success: function(html) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Data Berhasil Dihapus',
                            showConfirmButton: false,
                            timer: 1500
                        })
                        console.log(html);
                        var url = "<?php echo base_url(); ?>pengeluaran/";
                        window.location.href = url;
                    }
                })
            } else {
                return;
            }
        })
    }
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Pengeluaran Barang</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>dashboard">home</a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo base_url(); ?>pengeluaran/add/21001" class="btn btn-app">
                                <i class="fas fa-user"></i> JAKARTA
                            </a>
                            <br />
                            PENGELUARAN BARANG JAKARTA
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Pengeluaran</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <th>PIC</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $totals = 0;
                                        if (!empty($pengeluaranjkt)) {
                                            for ($a = 0; $a < count($pengeluaranjkt); $a++) { ?>
                                                <?php
                                                $idpengeluaranjkt = $pengeluaranjkt[$a]['idbarangkeluar'];
                                                $total = $pengeluaranjkt[$a]['qtykeluar'] * $pengeluaranjkt[$a]['hargasatuan'];
                                                $totals = $totals + $total;
                                                ?>
                                                <tr id="pengeluaranjkt<?php echo $idpengeluaranjkt; ?>">
                                                    <td><?php echo $a + 1 ?></td>
                                                    <td><?php echo $idpengeluaranjkt ?></td>
                                                    <td><?php echo $pengeluaranjkt[$a]['tanggal'] ?></td>
                                                    <td><?php echo $pengeluaranjkt[$a]['ketkeluar'] ?></td>
                                                    <td><?php echo $pengeluaranjkt[$a]['kodebarang'] ?></td>
                                                    <td><?php echo $pengeluaranjkt[$a]['namabarang'] ?></td>
                                                    <td align="right"><?php echo number_format($pengeluaranjkt[$a]['qtykeluar']) ?></td>
                                                    <td align="right"><?php echo number_format($pengeluaranjkt[$a]['hargasatuan']) ?></td>
                                                    <td align="right"><?php echo number_format($total); ?></td>
                                                    <td><?php echo $pengeluaranjkt[$a]['realname'] ?></td>
                                                    <td>
                                                        <a class="btn btn-large btn-success " href="<?php echo base_url('pengeluaran/detail/') . $pengeluaranjkt[$a]['idbarangkeluar']; ?>">Detail</a>
                                                        | <a class="btn btn-large btn-danger" href="javascript:deleteData('pengeluaranjkt<?php echo $pengeluaranjkt[$a]['idbarangkeluar']; ?>')">Delete</a>
                                                    </td>
                                                </tr>
                                        <?php }
                                        } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><b><?php echo number_format($totals); ?></b></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Pengeluaran</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <th>PIC</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo base_url(); ?>pengeluaran/add/21002" class="btn btn-app">
                                <i class="fas fa-user"></i> TASIK
                            </a>
                            <br />
                            PENGELUARAN BARANG TASIK
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table id="example2" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Pengeluaran</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <th>PIC</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $totals = 0;
                                        if (!empty($pengeluarantsk)) {
                                            for ($a = 0; $a < count($pengeluarantsk); $a++) { ?>
                                                <?php
                                                $idpengeluarantsk = $pengeluarantsk[$a]['idbarangkeluar'];
                                                $total = $pengeluarantsk[$a]['qtykeluar'] * $pengeluarantsk[$a]['hargasatuan'];
                                                $totals = $totals + $total;
                                                ?>
                                                <tr id="pengeluarantsk<?php echo $idpengeluarantsk; ?>">
                                                    <td><?php echo $a + 1 ?></td>
                                                    <td><?php echo $idpengeluarantsk ?></td>
                                                    <td><?php echo $pengeluarantsk[$a]['tanggal'] ?></td>
                                                    <td><?php echo $pengeluarantsk[$a]['ketkeluar'] ?></td>
                                                    <td><?php echo $pengeluarantsk[$a]['kodebarang'] ?></td>
                                                    <td><?php echo $pengeluarantsk[$a]['namabarang'] ?></td>
                                                    <td align="right"><?php echo number_format($pengeluarantsk[$a]['qtykeluar']) ?></td>
                                                    <td align="right"><?php echo number_format($pengeluarantsk[$a]['hargasatuan']) ?></td>
                                                    <td align="right"><?php echo number_format($total); ?></td>
                                                    <td><?php echo $pengeluarantsk[$a]['realname'] ?></td>
                                                    <td>
                                                        <a class="btn btn-large btn-success " href="<?php echo base_url('pengeluaran/detail/') . $pengeluarantsk[$a]['idbarangkeluar']; ?>">Detail</a>
                                                        | <a class="btn btn-large btn-danger" href="javascript:deleteData('pengeluarantsk<?php echo $pengeluarantsk[$a]['idbarangkeluar']; ?>')">Delete</a>
                                                    </td>
                                                </tr>
                                        <?php }
                                        } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><b><?php echo number_format($totals); ?></b></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th>No</th>
                                            <th>Id Pengeluaran</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Kode Barang</th>
                                            <th style="width:30%">Nama Barang</th>
                                            <th>Qty Masuk</th>
                                            <th>Harga Satuan</th>
                                            <th>Total</th>
                                            <th>PIC</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>

        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>