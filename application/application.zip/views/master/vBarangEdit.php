<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<script type="text/javascript">
    function updateData() {
        if ($("#namabarang").val() == "" || $("#idbarang").val() == "" || $("#stock").val() == "" || $("#satuan").val() == "" || $("#kodebarang").val() == "" || $("#harga").val() == "") {
            Swal.fire({
                icon: 'warning',
                text: 'Harap Melengkapi Data!',
            })
            return;
        }

        var dataArray = {
            "barang": {
                "idbarang": $("#idbarang").val(),
                "kodebarang": $("#kodebarang").val(),
                "namabarang": $("#namabarang").val(),
                "stock": $("#stock").val(),
                "idsatuan": $("#satuan").val(),
                "hargaterakhir": $("#harga").val().replace(',', ''),
                "idcabang": $("#cabang").val()
            }
        }

        console.log(dataArray);
        // return;
        $.ajax({
            type: "POST",
            data: dataArray,
            url: '<?php echo base_url('barang/updateData/'); ?>' + $("#idbarang").val(),
            success: function(result) {
                Swal.fire({
                    icon: 'success',
                    title: 'Data Berhasil Di Update',
                    showConfirmButton: false,
                    timer: 1500
                })
                console.log(result);
                window.location = "<?php echo base_url(); ?>barang";
            }
        })

    }
</script>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Edit Barang</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url($this->uri->segment(1)); ?>"><?php echo $this->uri->segment(1); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(2); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            Edit Data Barang
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="card-body">
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Id Barang</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="idbarang" value="<?php echo $barang[0]['idbarang']; ?>" disabled placeholder="Barang Id">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail3" class="col-sm-2 col-form-label">Cabang</label>
                                    <div class="col-sm-10">
                                        <select class="form-control select2" style="width: 100%;" id="cabang">
                                            <option value="">-- Pilih Cabang--</option>
                                            <?php for ($a = 0; $a < count($cabang); $a++) {  ?>
                                                <option value="<?php echo $cabang[$a]['idcabang'] ?>" <?php if ($cabang[$a]['idcabang'] == $barang[0]['idcabang']) {
                                                                                                            echo "selected";
                                                                                                        } ?>>
                                                    <?php echo $cabang[$a]['cabang']  ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Kode Barang</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="kodebarang" placeholder="Kode Barang" value="<?php echo $barang[0]['kodebarang']; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Nama Barang</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="namabarang" placeholder="Nama Barang" value="<?php echo $barang[0]['namabarang']; ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="inputPassword3" class="col-sm-2 col-form-label">Stock</label>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control" id="stock" placeholder="Stock" value="<?php echo $barang[0]['stock']; ?>">
                                    </div>
                                    <div class="col-sm-4">
                                        <select class="form-control select2" style="width: 100%;" id="satuan">
                                            <option value="">-- Pilih Satuan--</option>
                                            <?php for ($a = 0; $a < count($satuan); $a++) {  ?>
                                                <option value="<?php echo $satuan[$a]['idsatuan'] ?>" <?php if ($satuan[$a]['idsatuan'] == $barang[0]['idsatuan']) {
                                                                                                            echo "selected";
                                                                                                        } ?>>
                                                    <?php echo $satuan[$a]['satuan']  ?>
                                                </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-2 col-form-label">Harga Pembelian</label>
                                    <div class="col-sm-10">
                                        <input type="text" onClick="this.select();" class="form-control" id="harga" placeholder="Harga Pembelian" value="<?php echo number_format($barang[0]['hargaterakhir']); ?>">
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button onclick="updateData()" class="btn btn-info swalDefaultSuccess">Simpan</button>
                                <!-- <button class="btn btn-default float-right">Cancel</button> -->
                            </div>
                            <!-- /.card-footer -->
                        </div>
                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>



        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>