<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Preview Import Excell</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>dashboard">home</a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="card-body">
                <div class="box-body table-responsive">
                    <?php echo form_open('barang/saveInventarisBatch'); ?>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Id Inventaris</th>
                                <th>Tgl Pembelian</th>
                                <th>Kategori</th>
                                <th>Kode</th>
                                <th>SN</th>
                                <th>Nama</th>
                                <th>Merk</th>
                                <th>Lokasi</th>
                                <th>Kondisi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $jum = count($sheetData);
                            if (!empty($sheetData)) {
                                for ($a = 0; $a < $jum; $a++) { ?>
                                    <tr>
                                        <td><?php echo $a + 1 ?></td>
                                        <td><input name="idinventaris[]" value="<?php echo $sheetData[$a]['0']; ?>"></td>
                                        <td><input name="tglpembelian[]" value="<?php echo $sheetData[$a]['1']; ?>"></td>
                                        <td><input name="kategori[]" value="<?php echo $sheetData[$a]['2']; ?>"></td>
                                        <td><input name="kode[]" value="<?php echo $sheetData[$a]['3']; ?>"></td>
                                        <td><input name="serialnumber[]" value="<?php echo $sheetData[$a]['4']; ?>"></td>
                                        <td><input name="nama[]" value="<?php echo $sheetData[$a]['5']; ?>"></td>
                                        <td><input name="merk[]" value="<?php echo $sheetData[$a]['6']; ?>"></td>
                                        <td><input name="lokasi[]" value="<?php echo $sheetData[$a]['7']; ?>"></td>
                                        <td><input name="kondisi[]" value="<?php echo $sheetData[$a]['8']; ?>"></td>
                                    </tr>
                            <?php }
                            }
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>Id Inventaris</th>
                                <th>Tgl Pembelian</th>
                                <th>Kategori</th>
                                <th>Kode</th>
                                <th>SN</th>
                                <th>Nama</th>
                                <th>Merk</th>
                                <th>Lokasi</th>
                                <th>Kondisi</th>
                            </tr>

                        </tfoot>
                    </table>

                </div>

            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            <?php echo form_close(); ?>

        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>