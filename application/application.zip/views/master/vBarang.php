<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>


<script type="text/javascript">
    function selectData(id) {
        let idData = $("#" + id + " td")[2].innerHTML;
        console.log(idData);
        $.ajax({
            success: function(html) {
                var url = "<?php echo base_url(); ?>barang/edit/" + idData;
                window.location.href = url;
            }
        });
    }

    function deleteData(id) {
        let idData = $("#" + id + " td")[2].innerHTML;
        Swal.fire({
            title: 'Apakah yakin data akan di hapus?',
            showCancelButton: true,
            confirmButtonText: `Delete`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>barang/delete/" + idData,
                    success: function(html) {
                        console.log(html);
                        var url = "<?php echo base_url(); ?>barang/";
                        window.location.href = url;
                    }
                })
            } else {
                return;
            }
        })
    }
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Barang</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>dashboard">home</a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo base_url(); ?>barang/add" class="btn btn-app">
                                <i class="fas fa-user"></i> Tambah Barang
                            </a>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            BARANG JAKARTA
                            <div class="card-tools">
                                <a href="<?php echo base_url('barang/print/21001') ?>" target="_blank" class="btn btn-primary"><i class="fas fa-print"></i> Print</a>
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Cabang</th>
                                            <th>Id</th>
                                            <th>Kode Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Stock</th>
                                            <th>Satuan</th>
                                            <th>Harga Beli</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($barangjkt)) {
                                            for ($a = 0; $a < count($barangjkt); $a++) { ?>
                                                <?php $idbarangjkt = $barangjkt[$a]['idbarang']; ?>
                                                <tr id="barangjkt<?php echo $idbarangjkt; ?>">
                                                    <td><?php echo $a + 1 ?></td>
                                                    <td><?php echo $barangjkt[$a]['cabang'] ?></td>
                                                    <td><?php echo $idbarangjkt ?></td>
                                                    <td><?php echo $barangjkt[$a]['kodebarang'] ?></td>
                                                    <td><?php echo $barangjkt[$a]['namabarang'] ?></td>
                                                    <td><?php echo $barangjkt[$a]['stock'] ?></td>
                                                    <td><?php echo $barangjkt[$a]['satuan'] ?></td>
                                                    <td><?php echo number_format($barangjkt[$a]['hargaterakhir'], 0, "", ".") ?></td>
                                                    <td>
                                                        <a class="btn btn-large btn-primary" href="javascript:selectData('barangjkt<?php echo $barangjkt[$a]['idbarang']; ?>')">Edit</a>
                                                        | <a class="btn btn-large btn-danger" href="javascript:deleteData('barangjkt<?php echo $barangjkt[$a]['idbarang']; ?>')">Delete</a>
                                                    </td>
                                                </tr>
                                        <?php }
                                        } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>No</th>
                                            <th>Cabang</th>
                                            <th>Id</th>
                                            <th>Kode Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Stock</th>
                                            <th>Satuan</th>
                                            <th>Harga Beli</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            BARANG TASIK
                            <div class="card-tools">
                                <a href="<?php echo base_url('barang/print/21002') ?>" target="_blank" class="btn btn-primary"><i class="fas fa-print"></i> Print</a>
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table id="example2" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Cabang</th>
                                            <th>Id</th>
                                            <th>Kode Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Stock</th>
                                            <th>Satuan</th>
                                            <th>Harga Beli</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($barangtsk)) {
                                            for ($a = 0; $a < count($barangtsk); $a++) { ?>
                                                <?php $idbarangtsk = $barangtsk[$a]['idbarang']; ?>
                                                <tr id="barangtsk<?php echo $idbarangtsk; ?>">
                                                    <td><?php echo $a + 1 ?></td>
                                                    <td><?php echo $barangtsk[$a]['cabang'] ?></td>
                                                    <td><?php echo $idbarangtsk ?></td>
                                                    <td><?php echo $barangtsk[$a]['kodebarang'] ?></td>
                                                    <td><?php echo $barangtsk[$a]['namabarang'] ?></td>
                                                    <td><?php echo $barangtsk[$a]['stock'] ?></td>
                                                    <td><?php echo $barangtsk[$a]['satuan'] ?></td>
                                                    <td><?php echo number_format($barangtsk[$a]['hargaterakhir'], 0, "", ".") ?></td>
                                                    <td>
                                                        <a class="btn btn-large btn-primary" href="javascript:selectData('barangtsk<?php echo $barangtsk[$a]['idbarang']; ?>')">Edit</a>
                                                        | <a class="btn btn-large btn-danger" href="javascript:deleteData('barangtsk<?php echo $barangtsk[$a]['idbarang']; ?>')">Delete</a>
                                                    </td>
                                                </tr>
                                        <?php }
                                        } ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>No</th>
                                            <th>Cabang</th>
                                            <th>Id</th>
                                            <th>Kode Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Stock</th>
                                            <th>Satuan</th>
                                            <th>Harga Beli</th>
                                            <th style="width:15%">Aksi</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->



</div>
<!--/. container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>