<!DOCTYPE html>
<html>

<?php
$query = "SELECT * FROM tblmprofile WHERE id='1'";
$appName = $this->db->query($query)->result_array()[0]['appname'];
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $appName; ?> | Bukti Penerimaan Barang</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 4 -->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/adminlte.min.css">

    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<body>
    <div class="wrapper">
        <!-- Main content -->
        <section class="invoice">
            <div class="row">
                <div class="col-12">
                    <h4>
                        <img src="<?php echo base_url(); ?>assets/images/logo.jpg" width="100"> <br />
                        <b>PT. TELAGA PELANGI </b>
                    </h4>
                </div>
                <!-- /.col -->
            </div>

            <div class="row">
                <div class="col-12">
                    <h5>
                        <b>
                            <center>Rekap Inventaris</center>
                        </b>
                    </h5>
                </div>
                <!-- /.col -->
            </div>

            <!-- info row -->
            <div class="row invoice-info">
                <div class="col-sm-2 invoice-col">
                    <address>
                        Tanggal Cetak<br />
                    </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-10 invoice-col">
                    <address>
                        : <?php echo date('l, d-m-Y');; ?><br />
                    </address>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- Table row -->
            <div class="row">
                <div class="col-12 table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kategori</th>
                                <th>Baru</th>
                                <th>Baik</th>
                                <th>Lama</th>
                                <th>Rusak</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($inventaris)) {
                                for ($a = 0; $a < count($inventaris); $a++) { ?>
                                    <tr>
                                        <td><?php echo $a + 1 ?></td>
                                        <td><?php echo $inventaris[$a]['kategori'] ?></td>
                                        <td><?php echo $inventaris[$a]['Baru'] ?></td>
                                        <td><?php echo $inventaris[$a]['Baik'] ?></td>
                                        <td><?php echo $inventaris[$a]['Lama'] ?></td>
                                        <td><?php echo $inventaris[$a]['Rusak'] ?></td>
                                    </tr>
                            <?php }
                            } ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
            <br />
            <br />
            <!-- Table row -->
            <!-- <div class="row">
                <div class="col-12 table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>
                                    <center>Bagian Gudang</center>
                                </th>
                                <th>
                                    <center>Penerima</center>
                                </th>
                                <th>
                                    <center>Mengetahui</center>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr height="100px">
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div> -->


        </section>
        <!-- /.content -->
    </div>
    <!-- ./wrapper -->

    <script type="text/javascript">
        // window.addEventListener("load", window.print());
    </script>
</body>

</html>