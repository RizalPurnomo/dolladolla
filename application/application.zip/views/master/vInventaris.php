<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<script src="<?php echo base_url() ?>assets/jquery-2.1.1.min.js"></script>


<script type="text/javascript">
    function getDetailJkt(id) {
        let no = $("#" + id + " td")[1].innerHTML;
        let kategori = $("#" + id + " td")[2].innerHTML;

        $.ajax({
            type: "POST",
            data: {
                "kategori": kategori
            },
            url: "<?php echo base_url(); ?>inventaris/getInventarisDetail/" + '21001',
            success: function(data) {
                myObj = JSON.parse(data);
                objInventaris = myObj['inventaris'];

                var txt = "";
                for (x in objInventaris) {

                    txt += `	
                            <tr id="inventaris${no}${parseInt(x) + parseInt(1)}" data-toggle="collapse"  class="accordion-toggle" data-target="#demo10">
                                <td>${parseInt(x) + parseInt(1)}</td>    
                                <td>${objInventaris[x].idinventaris}</td>
                                <td>${objInventaris[x].nama}</td>
                                <td>${objInventaris[x].merk}</td>
                                <td>${objInventaris[x].kode}</td>
                                <td>${objInventaris[x].serialnumber}</td>
                                <td>${objInventaris[x].tanggalpembelian}</td>
                                <td>${objInventaris[x].cabang}</td>
                                <td>${objInventaris[x].kondisi}</td>
                                <td>
                                    <a class="btn btn-sm btn-primary" href="javascript:selectData('inventaris${no}${parseInt(x) + parseInt(1)}')">Edit</a>
                                    | <a class="btn btn-sm btn-danger" href="javascript:deleteData('inventaris${no}${parseInt(x) + parseInt(1)}')">Delete</a>
                                </td>
                            </tr>						
                             `;
                }
                document.getElementById("detailjkt" + no).innerHTML = txt;

            }
        })
    }

    function getDetailTsk(id) {
        let no = $("#" + id + " td")[1].innerHTML;
        let kategori = $("#" + id + " td")[2].innerHTML;

        $.ajax({
            type: "POST",
            data: {
                "kategori": kategori
            },
            url: "<?php echo base_url(); ?>inventaris/getInventarisDetail/" + '21002',
            success: function(data) {
                myObj = JSON.parse(data);
                objInventaris = myObj['inventaris'];

                var txt = "";
                for (x in objInventaris) {

                    txt += `	
                            <tr id="inventaris${no}${parseInt(x) + parseInt(1)}" data-toggle="collapse"  class="accordion-toggle" data-target="#demo10">
                                <td>${parseInt(x) + parseInt(1)}</td>    
                                <td>${objInventaris[x].idinventaris}</td>
                                <td>${objInventaris[x].nama}</td>
                                <td>${objInventaris[x].merk}</td>
                                <td>${objInventaris[x].kode}</td>
                                <td>${objInventaris[x].serialnumber}</td>
                                <td>${objInventaris[x].tanggalpembelian}</td>
                                <td>${objInventaris[x].cabang}</td>
                                <td>${objInventaris[x].kondisi}</td>
                                <td>
                                    <a class="btn btn-sm btn-primary" href="javascript:selectData('inventaris${no}${parseInt(x) + parseInt(1)}')">Edit</a>
                                    | <a class="btn btn-sm btn-danger" href="javascript:deleteData('inventaris${no}${parseInt(x) + parseInt(1)}')">Delete</a>
                                </td>
                            </tr>						
                             `;
                }
                document.getElementById("detailtsk" + no).innerHTML = txt;

            }
        })
    }

    function selectData(id) {
        console.log(id);
        let idData = $("#" + id + " td")[1].innerHTML;
        $.ajax({
            success: function(html) {
                var url = "<?php echo base_url(); ?>inventaris/edit/" + idData;
                window.location.href = url;
            }
        });
    }

    function deleteData(id) {
        let idData = $("#" + id + " td")[1].innerHTML;
        Swal.fire({
            title: 'Apakah yakin data akan di hapus?',
            showCancelButton: true,
            confirmButtonText: `Delete`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>inventaris/delete/" + idData,
                    success: function(html) {
                        console.log(html);
                        var url = "<?php echo base_url(); ?>inventaris/";
                        window.location.href = url;
                    }
                })
            } else {
                return;
            }
        })
    }
</script>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Inventaris</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>dashboard">home</a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo base_url(); ?>inventaris/add" class="btn btn-app">
                                <i class="fas fa-user"></i> Tambah Inventaris
                            </a>
                        </div>
                        <!-- /.card-header -->


                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            INVENTARIS JAKARTA
                            <div class="card-tools">
                                <a href="<?php echo base_url('inventaris/print/21001') ?>" target="_blank" class="btn btn-primary"><i class="fas fa-print"></i> Print</a>
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table class="table table-condensed table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th style="width:8%"></th>
                                            <th style="width:8%">No</th>
                                            <th>Kategori</th>
                                            <th>Jumlah</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php for ($a = 0; $a < count($inventarisjkt); $a++) { ?>

                                            <tr id="inventarisjkt<?php echo $a + 1; ?>" data-toggle="collapse" data-target="#demo<?php echo $a + 1; ?>" class="accordion-toggle info">
                                                <td><button class="btn btn-default btn-xs" onclick="getDetailJkt('inventarisjkt<?php echo $a + 1; ?>')"><span class="fas fa-eye"></span></button></td>
                                                <td><?php echo $a + 1; ?></td>
                                                <td id="idinventarisjkt<?php echo $a + 1; ?>"><?php echo $inventarisjkt[$a]['kategori']; ?></td>
                                                <td><?php echo $inventarisjkt[$a]['jumlah']; ?></td>
                                            </tr>
                                            <td colspan="12" class="hiddenRow">
                                                <div class="accordian-body collapse" id="demo<?php echo $a + 1; ?>">
                                                    <table class="table table-striped table-bordered">
                                                        <thead>
                                                            <tr class="info">
                                                                <th>No</th>
                                                                <th>Id Inventaris</th>
                                                                <th>Nama</th>
                                                                <th>Merk</th>
                                                                <th>Kode</th>
                                                                <th>Serial Number</th>
                                                                <th>Tanggal</th>
                                                                <th>Lokasi</th>
                                                                <th>Kondisi</th>
                                                                <th>Aksi</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody id="detailjkt<?php echo $a + 1; ?>">


                                                        </tbody>
                                                    </table>

                                                </div>
                                            </td>
                                            </tr>
                                        <?php } ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            INVENTARIS TASIK
                            <div class="card-tools">
                                <a href="<?php echo base_url('inventaris/print/21002') ?>" target="_blank" class="btn btn-primary"><i class="fas fa-print"></i> Print</a>
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="box-body table-responsive">
                                <table class="table table-condensed table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th style="width:8%"></th>
                                            <th style="width:8%">No</th>
                                            <th>Kategori</th>
                                            <th>Jumlah</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php for ($a = 0; $a < count($inventaristsk); $a++) { ?>

                                            <tr id="inventaristsk<?php echo $a + 1; ?>" data-toggle="collapse" data-target="#demo<?php echo $a + 1; ?>" class="accordion-toggle info">
                                                <td><button class="btn btn-default btn-xs" onclick="getDetailTsk('inventaristsk<?php echo $a + 1; ?>')"><span class="fas fa-eye"></span></button></td>
                                                <td><?php echo $a + 1; ?></td>
                                                <td id="idinventaristsk<?php echo $a + 1; ?>"><?php echo $inventaristsk[$a]['kategori']; ?></td>
                                                <td><?php echo $inventaristsk[$a]['jumlah']; ?></td>
                                            </tr>
                                            <td colspan="12" class="hiddenRow">
                                                <div class="accordian-body collapse" id="demo<?php echo $a + 1; ?>">
                                                    <table class="table table-striped table-bordered">
                                                        <thead>
                                                            <tr class="info">
                                                                <th>No</th>
                                                                <th>Id Inventaris</th>
                                                                <th>Nama</th>
                                                                <th>Merk</th>
                                                                <th>Kode</th>
                                                                <th>Serial Number</th>
                                                                <th>Tanggal</th>
                                                                <th>Lokasi</th>
                                                                <th>Kondisi</th>
                                                                <th>Aksi</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody id="detailtsk<?php echo $a + 1; ?>">


                                                        </tbody>
                                                    </table>

                                                </div>
                                            </td>
                                            </tr>
                                        <?php } ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <!-- ./card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->



</div>
<!--/. container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>