<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Import Excell</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>dashboard">home</a></li>
                        <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <style>
                h3 {
                    font-family: Verdana;
                    font-size: 14pt;
                    font-style: normal;
                    font-weight: bold;
                    color: red;
                    text-align: center;
                }

                table.tr {
                    font-family: Verdana;
                    color: black;
                    font-size: 12pt;
                    font-style: normal;
                    font-weight: bold;
                    text-align: left;
                }
            </style>
            <h3><u>Import/Export using phpspreadsheet in codeigniter</u></h3>
            <?php echo form_open_multipart('backup/importInventaris', array('name' => 'spreadsheet')); ?>
            <table align="center" cellpadding="5">
                <tr>
                    <td>File :</td>
                    <td><input type="file" size="40px" name="upload_file" /></td>
                    <td class="error"><?php echo form_error('name'); ?></td>
                    <td colspan="5" align="center">
                        <input type="submit" value="Import Users" />
                    </td>
                </tr>
            </table>
            <?php echo form_close(); ?>



        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('footer'); ?>