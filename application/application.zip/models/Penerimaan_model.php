<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penerimaan_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }


    public function getAllData()
    {
        $sql = "select * from tblbarangmasuk a
            inner join tblmuser b on b.iduser=a.iduser
            order by idbarangmasuk desc";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDataByIdCabang($idcabang)
    {
        $sql = "select * from tblbarangmasuk a
            inner join tblmuser b on b.iduser=a.iduser
            INNER JOIN tblbarangmasukdetail c ON c.idbarangmasuk=a.idbarangmasuk
            inner join tblmbarang d on d.idbarang=c.idbarang
            where a.idcabang='$idcabang'
            order by a.idbarangmasuk desc";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getAllDataDetail()
    {
        $sql = "SELECT * FROM tblbarangmasuk a
            INNER JOIN tblbarangmasukdetail b ON a.idbarangmasuk=b.idbarangmasuk
            INNER JOIN tblmbarang c ON c.idbarang=b.idbarang
            INNER JOIN tblmuser d ON d.iduser=a.iduser
            ORDER BY a.idbarangmasuk DESC";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDataById($idData)
    {
        $sql = "select * from tblbarangmasuk a
            inner join tblbarangmasukdetail b on a.idbarangmasuk=b.idbarangmasuk
            inner join tblmbarang c on c.idbarang=b.idbarang
            inner join tblmuser d on d.iduser=a.iduser
            inner join tblmsatuan e on e.idsatuan=c.idsatuan
            where a.idbarangmasuk='$idData'";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDetailDataById($idData)
    {
        $sql = "SELECT * FROM tblbarangmasuk a
            INNER JOIN tblbarangmasukdetail b ON a.idbarangmasuk=b.idbarangmasuk
            WHERE a.idbarangmasuk='$idData'";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDetailDataByIdBarang($idBarang)
    {
        $sql = "select * from tblbarangmasukdetail a
            inner join tblbarangmasuk b on a.idbarangmasuk=b.idbarangmasuk
            inner join tblmbarang c on a.idbarang=c.idbarang
            where a.idbarang='$idBarang'";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getIdData($thn)
    {
        $idData = "";
        $sql = "SELECT MAX(idbarangmasuk) AS maxdata FROM tblbarangmasuk WHERE idbarangmasuk LIKE '$thn%'";
        $qry = $this->db->query($sql)->result_array();
        $maxData = $qry[0]['maxdata'];
        if (empty($maxData)) {
            $idData = $thn . "001";
        } else {
            $maxData++;
            $idData = $maxData;
        }
        return $idData;
    }

    public function saveData($data, $tabel)
    {
        $this->db->insert($tabel, $data);
    }

    public function deleteData($id, $tabel)
    {
        $this->db->where('idbarangmasuk', $id);
        $this->db->delete($tabel);
    }



    // public function updateData($id, $data, $tabel)
    // {
    //     $this->db->where('idbarangmasuk', $id);
    //     $this->db->update($tabel, $data);
    //     return  "Data " . $id . " Berhasil Diupdate";
    // }

}
