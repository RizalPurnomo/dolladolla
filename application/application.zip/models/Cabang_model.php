<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Cabang_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }


    public function getAllData()
    {
        $sql = "SELECT * FROM tblmcabang";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    // public function getDataById($idData)
    // {
    //     $query = "SELECT * FROM tblmsprofile WHERE id='$idData'";
    //     $sql = $this->db->query($query);
    //     return $sql->result_array();
    // }

    // public function getIdData($thn)
    // {
    //     $idData = "";
    //     $sql = "SELECT MAX(idsatuan) AS maxdata FROM tblmsatuan WHERE idsatuan LIKE '$thn%'";
    //     $qry = $this->db->query($sql)->result_array();
    //     $maxData = $qry[0]['maxdata'];
    //     if (empty($maxData)) {
    //         $idData = $thn . "001";
    //     } else {
    //         $maxData++;
    //         $idData = $maxData;
    //     }
    //     return $idData;
    // }

    // public function saveData($data, $tabel)
    // {
    //     $this->db->insert($tabel, $data);
    // }

    // public function updateData($id, $data, $tabel)
    // {
    //     $this->db->where('idsatuan', $id);
    //     $this->db->update($tabel, $data);
    //     return  "Data " . $id . " Berhasil Diupdate";
    // }

    // public function deleteData($id, $tabel)
    // {
    //     $this->db->where('idsatuan', $id);
    //     $this->db->delete($tabel);
    // }
}
