<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengeluaran_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }


    public function getAllData()
    {
        $sql =
            "select * from tblbarangkeluar a
            inner join tblmuser b on b.iduser=a.iduser
            order by idbarangkeluar desc";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDataByIdCabang($idcabang)
    {
        $sql = "SELECT * FROM tblbarangkeluar a
        INNER JOIN tblbarangkeluardetail b ON a.idbarangkeluar=b.idbarangkeluar
        INNER JOIN tblmbarang c ON c.idbarang=b.idbarang
        INNER JOIN tblmuser d ON d.iduser=a.iduser
        WHERE a.idcabang='$idcabang'
        ORDER BY a.idbarangkeluar DESC";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }
    public function getAllDataDetail()
    {
        $sql = "SELECT * FROM tblbarangkeluar a
            INNER JOIN tblbarangkeluardetail b ON a.idbarangkeluar=b.idbarangkeluar
            INNER JOIN tblmbarang c ON c.idbarang=b.idbarang
            INNER JOIN tblmuser d ON d.iduser=a.iduser
            ORDER BY a.idbarangkeluar DESC";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDetailDataByIdBarang($idBarang)
    {
        $sql = "select * from tblbarangkeluardetail a
            inner join tblbarangkeluar b on a.idbarangkeluar=b.idbarangkeluar
            inner join tblmbarang c on a.idbarang=c.idbarang
            where a.idbarang='$idBarang'";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDataById($idData)
    {
        $sql = "select * from tblbarangkeluar a
            inner join tblbarangkeluardetail b on a.idbarangkeluar=b.idbarangkeluar
            inner join tblmbarang c on c.idbarang=b.idbarang
            inner join tblmuser d on d.iduser=a.iduser
            inner join tblmsatuan e on e.idsatuan=c.idsatuan
            where a.idbarangkeluar='$idData'";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDetailDataById($idData)
    {
        $sql = "SELECT * FROM tblbarangkeluar a
            INNER JOIN tblbarangkeluardetail b ON a.idbarangkeluar=b.idbarangkeluar
            WHERE a.idbarangkeluar='$idData'";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getIdData($thn)
    {
        $idData = "";
        $sql = "SELECT MAX(idbarangkeluar) AS maxdata FROM tblbarangkeluar WHERE idbarangkeluar LIKE '$thn%'";
        $qry = $this->db->query($sql)->result_array();
        $maxData = $qry[0]['maxdata'];
        if (empty($maxData)) {
            $idData = $thn . "001";
        } else {
            $maxData++;
            $idData = $maxData;
        }
        return $idData;
    }

    public function saveData($data, $tabel)
    {
        $this->db->insert($tabel, $data);
    }

    public function deleteData($id, $tabel)
    {
        $this->db->where('idbarangkeluar', $id);
        $this->db->delete($tabel);
    }



    // public function updateData($id, $data, $tabel)
    // {
    //     $this->db->where('idbarangkeluar', $id);
    //     $this->db->update($tabel, $data);
    //     return  "Data " . $id . " Berhasil Diupdate";
    // }

}
