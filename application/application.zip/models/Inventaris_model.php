<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Inventaris_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }


    public function getAllData()
    {
        $sql = "SELECT count(idinventaris) as jumlah,a.* FROM tblminventaris a
            group by kategori
            order by kategori,kode";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getDataByIdCabang($idcabang)
    {
        $sql = "SELECT count(idinventaris) as jumlah,a.* FROM tblminventaris a
            WHERE idcabang='$idcabang'
            group by kategori
            order by kategori,kode";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getRekap($idcabang)
    {
        $sql = "SELECT 
            SUM(CASE WHEN kondisi = 'Baru' THEN 1 ELSE 0 END) AS Baru, 
            SUM(CASE WHEN kondisi = 'Baik' THEN 1 ELSE 0 END) AS Baik,
            SUM(CASE WHEN kondisi = 'Lama' THEN 1 ELSE 0 END) AS Lama, 
            SUM(CASE WHEN kondisi = 'Rusak' THEN 1 ELSE 0 END) AS Rusak,
            a.* FROM tblminventaris a
            WHERE idcabang='$idcabang'
            GROUP BY kategori
            ORDER BY kategori,kode";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getInventarisByKategori($kategori, $idcabang)
    {
        $sql = "SELECT * FROM tblminventaris a
            inner join tblmcabang b on a.idcabang=b.idcabang
            where a.kategori='$kategori' and a.idcabang='$idcabang' order by a.tanggalpembelian desc";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getInventarisByid($id)
    {
        $sql = "SELECT * FROM tblminventaris
            where idinventaris='$id'";
        $qry = $this->db->query($sql);
        return $qry->result_array();
    }

    public function getIdData($thn)
    {
        $idData = "";
        $sql = "SELECT MAX(idinventaris) AS maxdata FROM tblminventaris WHERE idinventaris LIKE '$thn%'";
        $qry = $this->db->query($sql)->result_array();
        $maxData = $qry[0]['maxdata'];
        if (empty($maxData)) {
            $idData = $thn . "001";
        } else {
            $maxData++;
            $idData = $maxData;
        }
        return $idData;
    }

    public function saveData($data, $tabel)
    {
        $this->db->insert($tabel, $data);
    }

    public function updateData($id, $data, $tabel)
    {
        $this->db->where('idinventaris', $id);
        $this->db->update($tabel, $data);
        return  "Data " . $id . " Berhasil Diupdate";
    }

    public function deleteData($id, $tabel)
    {
        $this->db->where('idinventaris', $id);
        $this->db->delete($tabel);
    }

    public function getDataById($idData)
    {
        $query = "SELECT * FROM tblminventaris WHERE idinventaris='$idData'";
        $sql = $this->db->query($query);
        return $sql->result_array();
    }
}
